# ネトレ（NetTre）— プロジェクト引き継ぎ

## 概要
CCNAなどネットワーク資格向けの、スマホ特化の問題演習iOSアプリ。
Ping-t がスマホで使いにくい（PCレイアウト）という不満が出発点。
目標は「Ping-tレベルの問題演習を、通勤中に片手で」。App Store で公開する。

- アプリ名（仮）：ネトレ - ネットワーク資格ドリル
- サブタイトル（仮）：通勤1問、CCNA対策をスキマ時間で
- 名前は未確定。App Store Connect での仮登録と J-PlatPat の商標検索がまだ。

## 絶対に守ること（コンテンツ・法務）
- Ping-t・市販参考書の問題や解説を転載・改変して使わない（著作権）。
- 実際の試験問題の再現（ブレインダンプ）は禁止（Cisco の受験規約に違反する）。
- 「CCNA」「Cisco」はアプリ名の先頭に置かない。サブタイトルや説明文で「CCNA対策」のように説明的に使う。
- アプリ名に「Ping」を含めない（Ping-t との混同を避ける）。
- 問題はすべてオリジナル。AIで下書きした問題も、技術的な正確さを人が確認してから収録する。

## プロダクト方針
- 1問30秒、片手で操作できるUI
- 間隔反復（SM-2 の簡略版）で、間違えた問題を翌日に、正解した問題は間隔を広げて再出題
- 自動生成できる問題（サブネット計算 → 今後 ACL・ワイルドカードマスクなど）で問題数を確保する
- MVP：サブネット自動出題 ＋ 手書き問題を少し。有料化は問題数がそろってから（買い切り or 分野別課金）

## 現在のファイル
| パス | 内容 |
|---|---|
| Sources/Models/Question.swift | 問題モデル（single / multiple / input）、回答判定、`ReviewState`（間隔反復） |
| Sources/Generators/SubnetQuestionGenerator.swift | IPv4/Subnet ユーティリティ、seed 付き乱数（SplitMix64）、サブネット問題5種の自動生成 |
| Resources/questions_sample.json | 手書き問題のサンプル3問（`Question` と同じスキーマ） |

### 設計上の決まり
- 問題IDの形式：手書きは `<domain略>-<連番>`（例 `net-fund-0001`）、自動生成は `gen-subnet-<type>-<seed>`
- 自動生成問題は seed から完全に再現できる → 学習履歴には seed（ID）だけ保存すればよい
- `ReviewState` は問題本体と分けて端末内に保存する（SwiftData か JSON。まだ未決定）
- `version` は問題を修正したら上げる。履歴の扱いに使う予定
- domain は CCNA 200-301 の分野に合わせる：network-fundamentals / network-access / ip-connectivity / ip-services / security-fundamentals / automation-programmability

## 検証の状況
- サブネットの計算式（ネットワーク・ブロードキャスト・マスク・ホスト数・最終ホスト・ブロックサイズ）は、
  Python の ipaddress で 10 万ケース照合して誤りゼロ。
- **Swift のコンパイルはまだ一度もしていない**（作成した環境に Swift がなかった）。最初にビルドを通すこと。

## 既知の問題・TODO
1. `makeDistractors` で誤答が3つそろわない場合がある（例：/8 のマスク問題では wider が正解と同じになり除外される）。
   その場合は選択肢が3つになる → 誤答が足りなければ補充するロジックを追加する。
2. /30 の hostCount では誤答に「0」が出る。不自然なので除外する。
3. `make()` 内の `choices.first { ... }!` の強制アンラップは、上の修正後に安全か確認する。
4. ユニットテスト未作成。Swift Testing で、計算式と「選択肢の重複なし・正解がちょうど1つ」を検証するテストを書く。

## 次にやること（優先順）
1. Xcode プロジェクト作成（SwiftUI、iOS 17+）、既存ファイルを取り込んでビルドを通す
2. 上の TODO 1〜4 を修正し、テストを追加
3. 出題画面（1問ずつ表示 → 回答 → 正誤と解説 → 次へ）を SwiftUI で作る
4. 学習履歴の保存（SwiftData）と、復習キュー（due が来た問題を優先して出す）
5. 分野別メニュー、成績画面
