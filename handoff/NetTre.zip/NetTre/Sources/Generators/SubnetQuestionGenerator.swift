import Foundation

// MARK: - IPv4 ユーティリティ

struct IPv4: Hashable, CustomStringConvertible {
    let value: UInt32
    init(_ value: UInt32) { self.value = value }
    init(_ a: UInt8, _ b: UInt8, _ c: UInt8, _ d: UInt8) {
        value = UInt32(a) << 24 | UInt32(b) << 16 | UInt32(c) << 8 | UInt32(d)
    }
    var description: String {
        [24, 16, 8, 0].map { String((value >> UInt32($0)) & 0xFF) }.joined(separator: ".")
    }
}

struct Subnet {
    let host: IPv4
    let prefix: Int   // 8...30

    var mask: IPv4 { IPv4(prefix == 0 ? 0 : UInt32.max << UInt32(32 - prefix)) }
    var network: IPv4 { IPv4(host.value & mask.value) }
    var broadcast: IPv4 { IPv4(network.value | ~mask.value) }
    var usableHosts: Int { (1 << (32 - prefix)) - 2 }
    var firstHost: IPv4 { IPv4(network.value + 1) }
    var lastHost: IPv4 { IPv4(broadcast.value - 1) }
}

// MARK: - 再現可能な乱数（seed から同じ問題を再生成できる）

struct SeededRNG: RandomNumberGenerator {
    private var state: UInt64
    init(seed: UInt64) { state = seed == 0 ? 0x9E3779B97F4A7C15 : seed }
    mutating func next() -> UInt64 {            // SplitMix64
        state &+= 0x9E3779B97F4A7C15
        var z = state
        z = (z ^ (z >> 30)) &* 0xBF58476D1CE4E5B9
        z = (z ^ (z >> 27)) &* 0x94D049BB133111EB
        return z ^ (z >> 31)
    }
}

// MARK: - 出題パターン

enum SubnetQuestionType: String, CaseIterable {
    case networkAddress, broadcastAddress, hostCount, maskFromPrefix, lastHost
}

struct SubnetQuestionGenerator {

    /// seed と種類を指定して1問生成。履歴には seed を保存すれば同じ問題を復習できる。
    static func make(type: SubnetQuestionType, seed: UInt64, difficulty: Difficulty = .standard) -> Question {
        var rng = SeededRNG(seed: seed)
        let subnet = randomSubnet(using: &rng, difficulty: difficulty)
        let cidr = "\(subnet.host)/\(subnet.prefix)"

        let stem: String
        let correct: String
        let explanation: String

        switch type {
        case .networkAddress:
            stem = "\(cidr) が所属するネットワークアドレスはどれか。"
            correct = subnet.network.description
            explanation = """
            /\(subnet.prefix) のサブネットマスクは \(subnet.mask)。
            ホストアドレスとマスクの論理積（AND）を取ると \(subnet.network) になる。
            \(blockSizeHint(subnet))
            """
        case .broadcastAddress:
            stem = "\(cidr) のブロードキャストアドレスはどれか。"
            correct = subnet.broadcast.description
            explanation = """
            ネットワークアドレスは \(subnet.network)。
            ホスト部のビットをすべて1にすると \(subnet.broadcast) になる。
            \(blockSizeHint(subnet))
            """
        case .hostCount:
            stem = "/\(subnet.prefix) のサブネットで割り当て可能なホスト数はいくつか。"
            correct = String(subnet.usableHosts)
            explanation = """
            ホスト部は 32 − \(subnet.prefix) = \(32 - subnet.prefix) ビット。
            2^\(32 - subnet.prefix) − 2（ネットワークアドレスとブロードキャストアドレス）= \(subnet.usableHosts)。
            """
        case .maskFromPrefix:
            stem = "/\(subnet.prefix) をドット10進表記のサブネットマスクで表したものはどれか。"
            correct = subnet.mask.description
            explanation = "先頭から \(subnet.prefix) ビットを1にすると \(subnet.mask) になる。"
        case .lastHost:
            stem = "\(cidr) のサブネットで、割り当て可能な最後のホストアドレスはどれか。"
            correct = subnet.lastHost.description
            explanation = """
            ブロードキャストアドレス \(subnet.broadcast) の1つ前、\(subnet.lastHost) が最後のホストアドレス。
            \(blockSizeHint(subnet))
            """
        }

        let distractors = makeDistractors(type: type, subnet: subnet, correct: correct, using: &rng)
        var options = ([correct] + distractors).shuffled(using: &rng)
        options = Array(options.prefix(4))
        let ids = ["a", "b", "c", "d"]
        let choices = zip(ids, options).map { Choice(id: $0, text: $1) }
        let answerId = choices.first { $0.text == correct }!.id

        return Question(
            id: "gen-subnet-\(type.rawValue)-\(seed)",
            kind: .single,
            domain: "network-fundamentals",
            tags: ["subnet", "ipv4", type.rawValue],
            difficulty: difficulty,
            stem: stem,
            choices: choices,
            answer: [answerId],
            explanation: explanation,
            version: 1
        )
    }

    // MARK: 内部処理

    private static func randomSubnet(using rng: inout SeededRNG, difficulty: Difficulty) -> Subnet {
        // 難易度でプレフィックスの範囲を変える（basic はオクテット境界）
        let prefix: Int
        switch difficulty {
        case .basic:    prefix = [8, 16, 24].randomElement(using: &rng)!
        case .standard: prefix = Int.random(in: 24...30, using: &rng)
        case .advanced: prefix = Int.random(in: 17...30, using: &rng)
        }
        // プライベートアドレス帯から選ぶ
        let host: IPv4
        switch Int.random(in: 0..<3, using: &rng) {
        case 0:  host = IPv4(10, rnd(&rng), rnd(&rng), rnd(&rng))
        case 1:  host = IPv4(172, UInt8.random(in: 16...31, using: &rng), rnd(&rng), rnd(&rng))
        default: host = IPv4(192, 168, rnd(&rng), rnd(&rng))
        }
        return Subnet(host: host, prefix: prefix)
    }

    private static func rnd(_ rng: inout SeededRNG) -> UInt8 { UInt8.random(in: 1...254, using: &rng) }

    /// ブロックサイズ（マジックナンバー）による暗算のヒント
    private static func blockSizeHint(_ s: Subnet) -> String {
        let octetIndex = (s.prefix - 1) / 8                     // 区切りが入るオクテット（0始まり）
        let bitsInOctet = s.prefix - octetIndex * 8
        guard bitsInOctet < 8 else { return "" }
        let block = 256 >> bitsInOctet
        return "暗算のコツ: 第\(octetIndex + 1)オクテットのブロックサイズは \(block)。その倍数で区切ると早い。"
    }

    /// よくある間違いを誤答にする
    private static func makeDistractors(type: SubnetQuestionType, subnet s: Subnet,
                                        correct: String, using rng: inout SeededRNG) -> [String] {
        var pool: [String] = []
        let neighbor = Subnet(host: IPv4(s.network.value &+ (1 << UInt32(32 - s.prefix))), prefix: s.prefix)
        let wider = Subnet(host: s.host, prefix: max(s.prefix - 1, 8))
        let narrower = Subnet(host: s.host, prefix: min(s.prefix + 1, 30))

        switch type {
        case .networkAddress:
            pool = [s.firstHost, neighbor.network, wider.network, narrower.network, s.broadcast].map(\.description)
        case .broadcastAddress:
            pool = [s.lastHost, neighbor.broadcast, wider.broadcast, narrower.broadcast, IPv4(s.broadcast.value &+ 1)].map(\.description)
        case .hostCount:
            let n = 1 << (32 - s.prefix)
            pool = [n, n - 1, n / 2 - 2, n * 2 - 2].map(String.init)        // −2 忘れ、桁ずれ
        case .maskFromPrefix:
            pool = [wider.mask, narrower.mask, IPv4(~s.mask.value)].map(\.description) // ワイルドカードマスクとの混同
        case .lastHost:
            pool = [s.broadcast, IPv4(s.lastHost.value &- 1), neighbor.lastHost, narrower.lastHost].map(\.description)
        }
        var seen: Set<String> = [correct]
        let unique = pool.filter { seen.insert($0).inserted }
        return Array(unique.shuffled(using: &rng).prefix(3))
    }
}
