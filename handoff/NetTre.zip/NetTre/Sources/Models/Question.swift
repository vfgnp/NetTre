import Foundation

// MARK: - 問題データモデル
// 手書き問題（JSON）と自動生成問題（サブネット等）を同じ型で扱う。

enum QuestionKind: String, Codable {
    case single      // 単一選択
    case multiple    // 複数選択（「2つ選べ」など）
    case input       // 入力式（サブネット計算など）
}

enum Difficulty: Int, Codable, Comparable {
    case basic = 1, standard = 2, advanced = 3
    static func < (l: Self, r: Self) -> Bool { l.rawValue < r.rawValue }
}

struct Choice: Codable, Hashable, Identifiable {
    let id: String          // "a", "b", ...
    let text: String
}

struct Question: Codable, Identifiable, Hashable {
    let id: String                  // 例: "net-fund-0001", 自動生成は "gen-subnet-<seed>"
    let kind: QuestionKind
    let domain: String              // 試験分野: "network-fundamentals" など
    let tags: [String]              // 細分類: ["subnet", "ipv4"]
    let difficulty: Difficulty
    let stem: String                // 問題文
    let choices: [Choice]           // input の場合は空
    let answer: [String]            // 正解の choice.id、input の場合は正解文字列
    let explanation: String         // 解説（Markdown可）
    let version: Int                // 問題修正時にインクリメント（学習履歴の扱いに使う）

    /// 回答の判定。選択式は集合一致、入力式は空白除去して比較。
    func isCorrect(_ response: [String]) -> Bool {
        switch kind {
        case .single, .multiple:
            return Set(response) == Set(answer)
        case .input:
            let norm: (String) -> String = { $0.filter { !$0.isWhitespace } }
            return response.map(norm) == answer.map(norm)
        }
    }
}

// MARK: - 学習履歴（間隔反復用）
// 問題本体とは分けて端末内に保存する。

struct ReviewState: Codable {
    let questionId: String
    var interval: Int = 0           // 次回までの日数
    var ease: Double = 2.5          // SM-2 の易しさ係数
    var streak: Int = 0             // 連続正解数
    var due: Date = .now

    /// SM-2 を簡略化した更新。correct=false なら翌日に再出題。
    mutating func record(correct: Bool, now: Date = .now) {
        if correct {
            streak += 1
            interval = streak == 1 ? 1 : (streak == 2 ? 3 : Int((Double(interval) * ease).rounded()))
            ease = min(ease + 0.1, 3.0)
        } else {
            streak = 0
            interval = 1
            ease = max(ease - 0.2, 1.3)
        }
        due = Calendar.current.date(byAdding: .day, value: interval, to: now) ?? now
    }
}
