import Testing
@testable import NetTre

// ※ 未実行。Xcode プロジェクトに取り込んでから実行すること。

struct SubnetMathTests {
    @Test func networkAndBroadcast() {
        let s = Subnet(host: IPv4(192, 168, 10, 77), prefix: 26)
        #expect(s.mask.description == "255.255.255.192")
        #expect(s.network.description == "192.168.10.64")
        #expect(s.broadcast.description == "192.168.10.127")
        #expect(s.lastHost.description == "192.168.10.126")
        #expect(s.usableHosts == 62)
    }

    @Test func nonOctetBoundary() {
        let s = Subnet(host: IPv4(172, 20, 133, 5), prefix: 20)
        #expect(s.network.description == "172.20.128.0")
        #expect(s.broadcast.description == "172.20.143.255")
    }
}

struct GeneratorTests {
    @Test(arguments: SubnetQuestionType.allCases)
    func choicesAreValid(type: SubnetQuestionType) {
        for seed in UInt64(1)...500 {
            for difficulty in [Difficulty.basic, .standard, .advanced] {
                let q = SubnetQuestionGenerator.make(type: type, seed: seed, difficulty: difficulty)
                let texts = q.choices.map(\.text)
                #expect(Set(texts).count == texts.count, "選択肢が重複: \(q.id)")
                #expect(q.answer.count == 1)
                #expect(q.choices.contains { $0.id == q.answer[0] })
                // TODO 1 を修正したら有効化
                // #expect(q.choices.count == 4, "選択肢が4つない: \(q.id)")
            }
        }
    }

    @Test func sameSeedSameQuestion() {
        let a = SubnetQuestionGenerator.make(type: .networkAddress, seed: 42)
        let b = SubnetQuestionGenerator.make(type: .networkAddress, seed: 42)
        #expect(a == b)
    }
}
